# coding:utf-8
__author__ = "zhou"
# create by zhou on 2020/8/6
import shutil
from pkg_resources import Requirement, resource_filename
from setuptools import setup,find_packages



setup(
    name="mysqlclient",
    packages=find_packages(),
    version='2.0.0',
    author='zhoukunpeng',
    author_email='18749679769@163.com',
    maintainer='zhoukunpeng',
    maintainer_email='18749679769@163.com',
    include_package_data=True,
    license='GPL-2.0',
    classifiers=[
        'License :: OSI Approved :: GNU General Public License (GPL)',
    ]
)